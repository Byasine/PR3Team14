﻿Imports System.Data.OleDb

Public Class Database1

    ' properties 3.1
    Public Property NodesDA As OleDbDataAdapter
    Public Property ArcsDA As OleDbDataAdapter
    Public Property DriversDA As OleDbDataAdapter
    Public Property MyDataSet As New DataSet
    Public Property DatabasePath As String
    Public Property usersDA

    ' constructor & 3.2
    Public Sub New(path As String)
        DatabasePath = path
        NodesDA = GetDataAdapter("SELECT * FROM Nodes")
        NodesDA.Fill(MyDataSet, "Nodes")
        ArcsDA = GetDataAdapter("SELECT * FROM Arcs")
        ArcsDA.Fill(MyDataSet, "Arcs")
        DriversDA = GetDataAdapter("SELECT * FROM Drivers")
        DriversDA.Fill(MyDataSet, "Drivers")
    End Sub

    ' 3.3
    Public Function GetDataAdapter(mySQL As String)
        Dim connStr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & DatabasePath
        Return New OleDbDataAdapter(mySQL, connStr)
    End Function

    ' getnodes function with the properties 3.4
    Public Function GetNodes() As SortedList(Of String, Node)
        Dim NodeList As New SortedList(Of String, Node)
        For Each r In MyDataSet.Tables("Nodes").Rows
            Dim n As New Node
            n.ID = r("ID")
            n.XCoord = r("XCoord")
            n.YCoord = r("YCoord")
            n.Delivery = r("Delivery")
            NodeList.Add(n.ID, n)
        Next
        Return NodeList
    End Function

    ' returns number of arcs from the Arcs table 3.5
    Public Function GetArcs(nlst As SortedList(Of String, Node)) As SortedList(Of String, Arc)
        Dim ArcList As New SortedList(Of String, Arc)
        For Each f In MyDataSet.Tables("Arcs").Rows
            Dim a As New Arc
            a.Tail = nlst(f("Tail"))
            a.Head = nlst(f("Head"))
            a.Cost = f("Distance")
            a.ID = a.Tail.ID & "-TO-" & a.Head.ID

            a.Tail.ArcsOut.Add(a)
            a.Head.ArcsIn.Add(a)

            ArcList.Add(a.ID, a)
        Next
        Return ArcList
    End Function

    ' sorted list as the value together with its ID property as its corresponding key
    Public Function GetDriver() As SortedList(Of String, Driver)
        Dim driveList As New SortedList(Of String, Driver)
        For Each d In MyDataSet.Tables("Drivers").Rows
            Dim newDrive As New Driver
            newDrive.ID = d("ID")
            newDrive.XCoord = d("XCoord")
            newDrive.YCoord = d("YCoord")
            newDrive.First = d("First")
            newDrive.Last = d("Last")
            driveList.Add(newDrive.ID, newDrive)
        Next
        Return driveList
    End Function

    '3.7 'update database with changes
    Public Sub UpdateDatabase(DA As OleDbDataAdapter, DS As DataSet, TableName As String)
        Dim myCommandBuilder As New OleDbCommandBuilder(DA)

        DA.UpdateCommand = myCommandBuilder.GetUpdateCommand
        DA.InsertCommand = myCommandBuilder.GetInsertCommand
        DA.DeleteCommand = myCommandBuilder.GetDeleteCommand

        Dim updateCount As Integer = DA.Update(DS.Tables(TableName))
        MessageBox.Show(updateCount & " records updated.")
    End Sub
    Public Sub New(IsUserData As Boolean)
        usersDA = GetDataAdapter("SELECT * FROM Users")
        usersDA.Fill(MyDataSet, "Users")
    End Sub
    Public Function UserFound(usr As String, pwd As String) As Boolean
        Dim r() As DataRow = MyDataSet.Tables("Users").Select("User = '" & usr & "' AND Password = '" & pwd & "'")
        If r.Length > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

End Class