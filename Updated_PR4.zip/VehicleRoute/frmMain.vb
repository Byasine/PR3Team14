﻿Public Class frmMain
    ' Sorted list of all forms
    Public Property FormSList As New SortedList(Of String, Form)

    ' initialize FormSList when the main form loads
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        With FormSList
            .Add("Dashboard", Nothing)
            .Add("Chart", Nothing)
            .Add("Map", Nothing)
            .Add("About", Nothing)
            .Add("Help", Nothing)
        End With
        LoadDashboardForm()
    End Sub

    'loads the network form with all the constrols
    Private Sub LoadDashboardForm()
        Dim DashboardForm As frmDashboard = GetForm("Dashboard")
        DashboardForm.MainForm = Me
        DashboardForm.Show()
        DashboardForm.BringToFront()
    End Sub

    ' retrieves a form by name if it exists, creates a new instance and returns otherwise
    Public Function GetForm(name As String) As Form
        If FormSList(name) IsNot Nothing Then
            Return FormSList(name)
        Else
            Select Case name
                Case "Dashboard"
                    FormSList(name) = New frmDashboard
                Case "Chart"
                    FormSList(name) = New frmChart
                Case "Map"
                    FormSList(name) = New frmMap
                Case "About"
                    FormSList(name) = New frmAbout
                Case "Help"
                    FormSList(name) = New frmHelp
            End Select
        End If
        With FormSList(name)
            .MdiParent = Me
            .WindowState = FormWindowState.Maximized
        End With
        Return FormSList(name)
    End Function

    Private Sub SolverWindowToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SolverWindowToolStripMenuItem.Click, SolverWindowToolStripButton.Click
        LoadDashboardForm()
    End Sub
    Private Sub DeliveryLocationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeliveryLocationToolStripMenuItem.Click
        Dim DashboardForm As frmDashboard = GetForm("Dashboard")
        DashboardForm.BringToFront()
        DashboardForm.AssignAllDeliveryLocations()
    End Sub
    Private Sub DriverRoutesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DriverRoutesToolStripMenuItem.Click
        Dim DashboardForm As frmDashboard = GetForm("Dashboard")
        DashboardForm.BringToFront()
        DashboardForm.AddAllLocationsToRoute()
    End Sub
    Private Sub MapToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles MapToolStripMenuItem.Click
        Dim NewForm As frmMap = GetForm("Map")
        NewForm.Show()
        NewForm.BringToFront()
    End Sub
    Private Sub ChartToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ChartToolStripMenuItem.Click
        Dim NewForm As frmChart = GetForm("Chart")
        NewForm.Show()
        NewForm.BringToFront()
    End Sub
    Private Sub AboutToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim NewForm As frmAbout = GetForm("About")
        NewForm.Show()
        NewForm.BringToFront()
    End Sub
    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Dim NewForm As frmHelp = GetForm("Help")
        NewForm.Show()
        NewForm.BringToFront()
    End Sub

    'Private Sub NodesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NodesToolStripMenuItem.Click
    '    Dim NewForm As frmNodes = GetForm("Nodes")
    '    NewForm.Show()
    '    NewForm.BringToFront()
    'End Sub

    'Private Sub ArcsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ArcsToolStripMenuItem.Click
    '    Dim NewForm As frmArcs = GetForm("Arcs")
    '    NewForm.Show()
    '    NewForm.BringToFront()
    'End Sub

    'Private Sub UsersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UsersToolStripMenuItem.Click
    '    Dim NewForm As frmUsers = GetForm("Users")
    '    NewForm.Show()
    '    NewForm.BringToFront()
    'End Sub

End Class
