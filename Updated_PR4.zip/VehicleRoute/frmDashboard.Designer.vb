﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.gbxDeliveryLocations = New System.Windows.Forms.GroupBox()
        Me.btnAssignAll = New System.Windows.Forms.Button()
        Me.txtAverageDistance = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.lstDelivery = New System.Windows.Forms.ListBox()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lstLocation = New System.Windows.Forms.ListBox()
        Me.cboDrivers = New System.Windows.Forms.ComboBox()
        Me.gbxDataTables = New System.Windows.Forms.GroupBox()
        Me.btnOpenTable = New System.Windows.Forms.Button()
        Me.lstData = New System.Windows.Forms.ListBox()
        Me.gbxDatabase = New System.Windows.Forms.GroupBox()
        Me.txtDatabasePath = New System.Windows.Forms.TextBox()
        Me.btnOpenDatabase = New System.Windows.Forms.Button()
        Me.gbxRoutes = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.trvRouteDetail = New System.Windows.Forms.TreeView()
        Me.btnAssignAll2 = New System.Windows.Forms.Button()
        Me.txtRouteLength = New System.Windows.Forms.TextBox()
        Me.btnSave2 = New System.Windows.Forms.Button()
        Me.lstRoute = New System.Windows.Forms.ListBox()
        Me.btnRemove2 = New System.Windows.Forms.Button()
        Me.btnAdd2 = New System.Windows.Forms.Button()
        Me.lstlocation2 = New System.Windows.Forms.ListBox()
        Me.cboDrivers2 = New System.Windows.Forms.ComboBox()
        Me.gbxDeliveryLocations.SuspendLayout()
        Me.gbxDataTables.SuspendLayout()
        Me.gbxDatabase.SuspendLayout()
        Me.gbxRoutes.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxDeliveryLocations
        '
        Me.gbxDeliveryLocations.Controls.Add(Me.btnAssignAll)
        Me.gbxDeliveryLocations.Controls.Add(Me.txtAverageDistance)
        Me.gbxDeliveryLocations.Controls.Add(Me.btnSave)
        Me.gbxDeliveryLocations.Controls.Add(Me.lstDelivery)
        Me.gbxDeliveryLocations.Controls.Add(Me.btnRemove)
        Me.gbxDeliveryLocations.Controls.Add(Me.btnAdd)
        Me.gbxDeliveryLocations.Controls.Add(Me.lstLocation)
        Me.gbxDeliveryLocations.Controls.Add(Me.cboDrivers)
        Me.gbxDeliveryLocations.Location = New System.Drawing.Point(22, 141)
        Me.gbxDeliveryLocations.Name = "gbxDeliveryLocations"
        Me.gbxDeliveryLocations.Size = New System.Drawing.Size(484, 395)
        Me.gbxDeliveryLocations.TabIndex = 9
        Me.gbxDeliveryLocations.TabStop = False
        Me.gbxDeliveryLocations.Text = "Delivery Locations"
        '
        'btnAssignAll
        '
        Me.btnAssignAll.Location = New System.Drawing.Point(254, 20)
        Me.btnAssignAll.Name = "btnAssignAll"
        Me.btnAssignAll.Size = New System.Drawing.Size(213, 33)
        Me.btnAssignAll.TabIndex = 7
        Me.btnAssignAll.Text = "Assign All"
        Me.btnAssignAll.UseVisualStyleBackColor = True
        '
        'txtAverageDistance
        '
        Me.txtAverageDistance.Location = New System.Drawing.Point(254, 299)
        Me.txtAverageDistance.Name = "txtAverageDistance"
        Me.txtAverageDistance.Size = New System.Drawing.Size(213, 22)
        Me.txtAverageDistance.TabIndex = 6
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(254, 338)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(213, 33)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'lstDelivery
        '
        Me.lstDelivery.FormattingEnabled = True
        Me.lstDelivery.ItemHeight = 16
        Me.lstDelivery.Location = New System.Drawing.Point(254, 59)
        Me.lstDelivery.Name = "lstDelivery"
        Me.lstDelivery.Size = New System.Drawing.Size(213, 228)
        Me.lstDelivery.TabIndex = 4
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(6, 338)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(213, 33)
        Me.btnRemove.TabIndex = 3
        Me.btnRemove.Text = "Remove"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(6, 299)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(213, 33)
        Me.btnAdd.TabIndex = 2
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lstLocation
        '
        Me.lstLocation.FormattingEnabled = True
        Me.lstLocation.ItemHeight = 16
        Me.lstLocation.Location = New System.Drawing.Point(6, 59)
        Me.lstLocation.Name = "lstLocation"
        Me.lstLocation.Size = New System.Drawing.Size(213, 228)
        Me.lstLocation.TabIndex = 1
        '
        'cboDrivers
        '
        Me.cboDrivers.FormattingEnabled = True
        Me.cboDrivers.Location = New System.Drawing.Point(6, 29)
        Me.cboDrivers.Name = "cboDrivers"
        Me.cboDrivers.Size = New System.Drawing.Size(213, 24)
        Me.cboDrivers.TabIndex = 0
        '
        'gbxDataTables
        '
        Me.gbxDataTables.Controls.Add(Me.btnOpenTable)
        Me.gbxDataTables.Controls.Add(Me.lstData)
        Me.gbxDataTables.Location = New System.Drawing.Point(22, 555)
        Me.gbxDataTables.Name = "gbxDataTables"
        Me.gbxDataTables.Size = New System.Drawing.Size(484, 204)
        Me.gbxDataTables.TabIndex = 8
        Me.gbxDataTables.TabStop = False
        Me.gbxDataTables.Text = "Data Tables"
        '
        'btnOpenTable
        '
        Me.btnOpenTable.Location = New System.Drawing.Point(320, 29)
        Me.btnOpenTable.Name = "btnOpenTable"
        Me.btnOpenTable.Size = New System.Drawing.Size(147, 35)
        Me.btnOpenTable.TabIndex = 1
        Me.btnOpenTable.Text = "Open Table"
        Me.btnOpenTable.UseVisualStyleBackColor = True
        '
        'lstData
        '
        Me.lstData.FormattingEnabled = True
        Me.lstData.ItemHeight = 16
        Me.lstData.Location = New System.Drawing.Point(6, 29)
        Me.lstData.Name = "lstData"
        Me.lstData.Size = New System.Drawing.Size(297, 132)
        Me.lstData.TabIndex = 0
        '
        'gbxDatabase
        '
        Me.gbxDatabase.Controls.Add(Me.txtDatabasePath)
        Me.gbxDatabase.Controls.Add(Me.btnOpenDatabase)
        Me.gbxDatabase.Location = New System.Drawing.Point(22, 31)
        Me.gbxDatabase.Name = "gbxDatabase"
        Me.gbxDatabase.Size = New System.Drawing.Size(1018, 90)
        Me.gbxDatabase.TabIndex = 7
        Me.gbxDatabase.TabStop = False
        Me.gbxDatabase.Text = "Database"
        '
        'txtDatabasePath
        '
        Me.txtDatabasePath.Location = New System.Drawing.Point(147, 35)
        Me.txtDatabasePath.Name = "txtDatabasePath"
        Me.txtDatabasePath.Size = New System.Drawing.Size(858, 22)
        Me.txtDatabasePath.TabIndex = 1
        '
        'btnOpenDatabase
        '
        Me.btnOpenDatabase.Location = New System.Drawing.Point(6, 30)
        Me.btnOpenDatabase.Name = "btnOpenDatabase"
        Me.btnOpenDatabase.Size = New System.Drawing.Size(122, 33)
        Me.btnOpenDatabase.TabIndex = 0
        Me.btnOpenDatabase.Text = "Open Database"
        Me.btnOpenDatabase.UseVisualStyleBackColor = True
        '
        'gbxRoutes
        '
        Me.gbxRoutes.Controls.Add(Me.Label1)
        Me.gbxRoutes.Controls.Add(Me.trvRouteDetail)
        Me.gbxRoutes.Controls.Add(Me.btnAssignAll2)
        Me.gbxRoutes.Controls.Add(Me.txtRouteLength)
        Me.gbxRoutes.Controls.Add(Me.btnSave2)
        Me.gbxRoutes.Controls.Add(Me.lstRoute)
        Me.gbxRoutes.Controls.Add(Me.btnRemove2)
        Me.gbxRoutes.Controls.Add(Me.btnAdd2)
        Me.gbxRoutes.Controls.Add(Me.lstlocation2)
        Me.gbxRoutes.Controls.Add(Me.cboDrivers2)
        Me.gbxRoutes.Location = New System.Drawing.Point(560, 141)
        Me.gbxRoutes.Name = "gbxRoutes"
        Me.gbxRoutes.Size = New System.Drawing.Size(480, 618)
        Me.gbxRoutes.TabIndex = 10
        Me.gbxRoutes.TabStop = False
        Me.gbxRoutes.Text = "Routes"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 419)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 17)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Route Detail"
        '
        'trvRouteDetail
        '
        Me.trvRouteDetail.Location = New System.Drawing.Point(6, 443)
        Me.trvRouteDetail.Name = "trvRouteDetail"
        Me.trvRouteDetail.Size = New System.Drawing.Size(461, 132)
        Me.trvRouteDetail.TabIndex = 8
        '
        'btnAssignAll2
        '
        Me.btnAssignAll2.Location = New System.Drawing.Point(254, 20)
        Me.btnAssignAll2.Name = "btnAssignAll2"
        Me.btnAssignAll2.Size = New System.Drawing.Size(213, 33)
        Me.btnAssignAll2.TabIndex = 7
        Me.btnAssignAll2.Text = "Assign All"
        Me.btnAssignAll2.UseVisualStyleBackColor = True
        '
        'txtRouteLength
        '
        Me.txtRouteLength.Location = New System.Drawing.Point(254, 299)
        Me.txtRouteLength.Name = "txtRouteLength"
        Me.txtRouteLength.Size = New System.Drawing.Size(213, 22)
        Me.txtRouteLength.TabIndex = 6
        '
        'btnSave2
        '
        Me.btnSave2.Location = New System.Drawing.Point(254, 338)
        Me.btnSave2.Name = "btnSave2"
        Me.btnSave2.Size = New System.Drawing.Size(213, 33)
        Me.btnSave2.TabIndex = 5
        Me.btnSave2.Text = "Save"
        Me.btnSave2.UseVisualStyleBackColor = True
        '
        'lstRoute
        '
        Me.lstRoute.FormattingEnabled = True
        Me.lstRoute.ItemHeight = 16
        Me.lstRoute.Location = New System.Drawing.Point(254, 59)
        Me.lstRoute.Name = "lstRoute"
        Me.lstRoute.Size = New System.Drawing.Size(213, 228)
        Me.lstRoute.TabIndex = 4
        '
        'btnRemove2
        '
        Me.btnRemove2.Location = New System.Drawing.Point(6, 338)
        Me.btnRemove2.Name = "btnRemove2"
        Me.btnRemove2.Size = New System.Drawing.Size(213, 33)
        Me.btnRemove2.TabIndex = 3
        Me.btnRemove2.Text = "Remove"
        Me.btnRemove2.UseVisualStyleBackColor = True
        '
        'btnAdd2
        '
        Me.btnAdd2.Location = New System.Drawing.Point(6, 299)
        Me.btnAdd2.Name = "btnAdd2"
        Me.btnAdd2.Size = New System.Drawing.Size(213, 33)
        Me.btnAdd2.TabIndex = 2
        Me.btnAdd2.Text = "Add"
        Me.btnAdd2.UseVisualStyleBackColor = True
        '
        'lstlocation2
        '
        Me.lstlocation2.FormattingEnabled = True
        Me.lstlocation2.ItemHeight = 16
        Me.lstlocation2.Location = New System.Drawing.Point(6, 59)
        Me.lstlocation2.Name = "lstlocation2"
        Me.lstlocation2.Size = New System.Drawing.Size(213, 228)
        Me.lstlocation2.TabIndex = 1
        '
        'cboDrivers2
        '
        Me.cboDrivers2.FormattingEnabled = True
        Me.cboDrivers2.Location = New System.Drawing.Point(6, 29)
        Me.cboDrivers2.Name = "cboDrivers2"
        Me.cboDrivers2.Size = New System.Drawing.Size(213, 24)
        Me.cboDrivers2.TabIndex = 0
        '
        'frmDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1083, 793)
        Me.Controls.Add(Me.gbxRoutes)
        Me.Controls.Add(Me.gbxDeliveryLocations)
        Me.Controls.Add(Me.gbxDataTables)
        Me.Controls.Add(Me.gbxDatabase)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmDashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dashboard"
        Me.gbxDeliveryLocations.ResumeLayout(False)
        Me.gbxDeliveryLocations.PerformLayout()
        Me.gbxDataTables.ResumeLayout(False)
        Me.gbxDatabase.ResumeLayout(False)
        Me.gbxDatabase.PerformLayout()
        Me.gbxRoutes.ResumeLayout(False)
        Me.gbxRoutes.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbxDeliveryLocations As GroupBox
    Friend WithEvents gbxDataTables As GroupBox
    Friend WithEvents gbxDatabase As GroupBox
    Friend WithEvents btnOpenDatabase As Button
    Friend WithEvents txtAverageDistance As TextBox
    Friend WithEvents btnSave As Button
    Friend WithEvents lstDelivery As ListBox
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents lstLocation As ListBox
    Friend WithEvents cboDrivers As ComboBox
    Friend WithEvents btnOpenTable As Button
    Friend WithEvents lstData As ListBox
    Friend WithEvents txtDatabasePath As TextBox
    Friend WithEvents btnAssignAll As Button
    Friend WithEvents gbxRoutes As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents trvRouteDetail As TreeView
    Friend WithEvents btnAssignAll2 As Button
    Friend WithEvents txtRouteLength As TextBox
    Friend WithEvents btnSave2 As Button
    Friend WithEvents lstRoute As ListBox
    Friend WithEvents btnRemove2 As Button
    Friend WithEvents btnAdd2 As Button
    Friend WithEvents lstlocation2 As ListBox
    Friend WithEvents cboDrivers2 As ComboBox
End Class
