﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.SolverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SolverWindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeliveryLocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DriverRoutesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SolutionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArcsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SolverToolStripMenuItem, Me.SolutionToolStripMenuItem, Me.DataToolStripMenuItem, Me.WindowToolStripMenuItem, Me.InfoToolStripMenuItem})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(1124, 28)
        Me.MenuStrip.TabIndex = 1
        Me.MenuStrip.Text = "MenuStrip1"
        '
        'SolverToolStripMenuItem
        '
        Me.SolverToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SolverWindowToolStripMenuItem, Me.DeliveryLocationToolStripMenuItem, Me.DriverRoutesToolStripMenuItem})
        Me.SolverToolStripMenuItem.Name = "SolverToolStripMenuItem"
        Me.SolverToolStripMenuItem.Size = New System.Drawing.Size(64, 24)
        Me.SolverToolStripMenuItem.Text = "Solver"
        '
        'SolverWindowToolStripMenuItem
        '
        Me.SolverWindowToolStripMenuItem.Name = "SolverWindowToolStripMenuItem"
        Me.SolverWindowToolStripMenuItem.Size = New System.Drawing.Size(207, 26)
        Me.SolverWindowToolStripMenuItem.Text = "Solver Window"
        '
        'DeliveryLocationToolStripMenuItem
        '
        Me.DeliveryLocationToolStripMenuItem.Name = "DeliveryLocationToolStripMenuItem"
        Me.DeliveryLocationToolStripMenuItem.Size = New System.Drawing.Size(207, 26)
        Me.DeliveryLocationToolStripMenuItem.Text = "Delivery Location"
        '
        'DriverRoutesToolStripMenuItem
        '
        Me.DriverRoutesToolStripMenuItem.Name = "DriverRoutesToolStripMenuItem"
        Me.DriverRoutesToolStripMenuItem.Size = New System.Drawing.Size(207, 26)
        Me.DriverRoutesToolStripMenuItem.Text = "Driver Routes"
        '
        'SolutionToolStripMenuItem
        '
        Me.SolutionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MapToolStripMenuItem, Me.ChartToolStripMenuItem})
        Me.SolutionToolStripMenuItem.Name = "SolutionToolStripMenuItem"
        Me.SolutionToolStripMenuItem.Size = New System.Drawing.Size(78, 24)
        Me.SolutionToolStripMenuItem.Text = "Solution"
        '
        'MapToolStripMenuItem
        '
        Me.MapToolStripMenuItem.Name = "MapToolStripMenuItem"
        Me.MapToolStripMenuItem.Size = New System.Drawing.Size(127, 26)
        Me.MapToolStripMenuItem.Text = "Map"
        '
        'ChartToolStripMenuItem
        '
        Me.ChartToolStripMenuItem.Name = "ChartToolStripMenuItem"
        Me.ChartToolStripMenuItem.Size = New System.Drawing.Size(127, 26)
        Me.ChartToolStripMenuItem.Text = "Chart"
        '
        'DataToolStripMenuItem
        '
        Me.DataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArcsToolStripMenuItem})
        Me.DataToolStripMenuItem.Name = "DataToolStripMenuItem"
        Me.DataToolStripMenuItem.Size = New System.Drawing.Size(55, 24)
        Me.DataToolStripMenuItem.Text = "Data"
        '
        'ArcsToolStripMenuItem
        '
        Me.ArcsToolStripMenuItem.Name = "ArcsToolStripMenuItem"
        Me.ArcsToolStripMenuItem.Size = New System.Drawing.Size(120, 26)
        Me.ArcsToolStripMenuItem.Text = "Arcs"
        '
        'WindowToolStripMenuItem
        '
        Me.WindowToolStripMenuItem.Name = "WindowToolStripMenuItem"
        Me.WindowToolStripMenuItem.Size = New System.Drawing.Size(78, 24)
        Me.WindowToolStripMenuItem.Text = "Window"
        '
        'InfoToolStripMenuItem
        '
        Me.InfoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem"
        Me.InfoToolStripMenuItem.Size = New System.Drawing.Size(49, 24)
        Me.InfoToolStripMenuItem.Text = "Info"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1124, 742)
        Me.Controls.Add(Me.MenuStrip)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "frmMain"
        Me.Text = "Network Solver"
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip As MenuStrip
    Friend WithEvents DataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SolutionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InfoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ArcsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MapToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SolverToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SolverWindowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeliveryLocationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DriverRoutesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WindowToolStripMenuItem As ToolStripMenuItem
End Class
