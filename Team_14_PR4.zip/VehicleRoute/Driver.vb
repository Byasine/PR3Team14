﻿Public Class Driver
    ' Dependencies: Node

    ' Arc properties
    Public Property ID As String
    Public Property First As String
    Public Property Last As String
    Public Property XCoord As Decimal
    Public Property YCoord As Decimal
    Public Property CenterNode As Node
    Public Property LocationSList As New SortedList(Of String, Decimal)
    Public Property DeliveryList As New List(Of String)
    Public Property RouteList As New List(Of String)
    Public Property DriverRoute As Route


    ' constructor
    Public Sub New()

    End Sub
End Class
