
Public Class Database
    'class properties
    Public Property MyDataSet As New DataSet
    Public Property NodesDA As OleDbDataAdapter
    Public Property ArcsDA As OleDbDataAdapter
    Public Property DriverDA As OleDbDataAdapter
    Public Property DatabasePath As String

    'default constructor
    Public Sub New(path As String)
        DatabasePath = path
        NodesDA = GetDataAdapter("SELECT * FROM Nodes")
        NodesDA.Fill(MyDataSet, "Nodes")
        ArcsDA = GetDataAdapter("SELECT * FROM Arcs WHERE Distance <= " & radius)
        ArcsDA.Fill(MyDataSet, "Arcs")
        DriverDA = GetDataAdapter("SELECT * FROM Driver")
        DriverDA.Fill(MyDataSet, "Driver")
    End Sub


    Function GetDataAdapter(mySql As String) As OleDbDataAdapter
        'create a database connection
        Dim adapter = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" &
            Application.StartupPath & "\Network.accdb"
        Return New OleDbDataAdapter(mySql, adapter)
    End Function

    Function GetNodes() As SortedList(Of String, Node)
        'create sql statement and parse it to the GetDataAdapter method
        Dim sql As String = "Select distinct tail from arcs"
        Dim nodeAdapter As OleDbDataAdapter = GetDataAdapter(sql)
        'Fill the dataset
        nodeAdapter.Fill(MyDataSet, "Nodes")
        'create Nodes 
        Dim sortedList As SortedList(Of String, Node) = New SortedList(Of String, Node)
        For Each Row As DataRow In MyDataSet.Tables("Nodes").Rows
            Dim name As String = Row.Item(0).ToString()
            Dim newNode As Node = New Node(name)
            sortedList.Add(name, newNode)
        Next
        MyDataSet.Clear()

        Return sortedList
    End Function

    Function GetArcs(nodeList As SortedList(Of String, Node)) As SortedList(Of String, Arc)
        'create sql statement and parse it to the GetDataAdapter method
        Dim sql As String = "SELECT * FROM Arcs"
        Dim adapter As OleDbDataAdapter = GetDataAdapter(sql)
        'Fill the dataset
        adapter.Fill(MyDataSet, "Arcs")
        'create Arcs
        Dim sortedList As SortedList(Of String, Arc) = New SortedList(Of String, Arc)
        For Each Row As DataRow In MyDataSet.Tables("Arcs").Rows
            Dim tail As String = Row.Item(0).ToString()
            Dim head As String = Row.Item(1).ToString()
            Dim distance As Decimal = Convert.ToDecimal(Row.Item(2).ToString())
            Dim tailNode As Node = nodeList.Item(tail)
            Dim headNode As Node = nodeList.Item(head)
            Dim newArc As Arc = New Arc(tailNode, headNode, distance)
            nodeList.Item(tail).ArcsOut.Add(newArc)
            nodeList.Item(head).ArcsIn.Add(newArc)
            sortedList.Add(newArc.ID, newArc)
        Next
        MyDataSet.Clear()

        Return sortedList

    End Function

    Function GetDriver() As SortedList(Of String, Driver)
    ' create sql statement and parse it to the getdriver 



    ' updates database with changes
    Public Sub UpdateDatabase(DA As OleDbDataAdapter, DS As DataSet, TableName As String)
        Dim myCommandBuilder As New OleDbCommandBuilder(DA)

        DA.UpdateCommand = myCommandBuilder.GetUpdateCommand
        DA.InsertCommand = myCommandBuilder.GetInsertCommand
        DA.DeleteCommand = myCommandBuilder.GetDeleteCommand

        Dim updateCount As Integer = DA.Update(DS.Tables(TableName))
        MessageBox.Show(updateCount & " records updated.")
    End Sub



End Class
