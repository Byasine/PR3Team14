﻿Imports Microsoft.SolverFoundation.Solvers
Imports Microsoft.SolverFoundation.Common
Imports Microsoft.SolverFoundation.Services
Public Class Optimization

    ' Dependencies: Network, Node, Arc
    Private VarSList As New SortedList(Of String, Integer)
    Private FunSList As New SortedList(Of String, Integer)
    Private myModel As SimplexSolver

    ' default constructor
    Public Sub New()

    End Sub

    ' Initialization of variable and function lists, and solver
    Private Sub InitSolver()
        VarSList.Clear()
        FunSList.Clear()
        myModel = New SimplexSolver
    End Sub

    ' Add a new variale to model
    Private Sub AddVar(varstr As String, lb As Decimal, ub As Decimal)
        VarSList.Add(varstr, 0)
        myModel.AddVariable(varstr, VarSList(varstr))
        myModel.SetBounds(VarSList(varstr), lb, ub)
    End Sub

    ' Add a new function to model
    Private Sub AddFun(funstr As String, lb As Decimal, ub As Decimal)
        FunSList.Add(funstr, 0)
        myModel.AddRow(funstr, FunSList(funstr))
        myModel.SetBounds(FunSList(funstr), lb, ub)
    End Sub

    ' Add an objective function
    Private Sub AddObj(funstr As String)
        FunSList.Add(funstr, 0)
        myModel.AddRow(funstr, FunSList(funstr))
    End Sub

    ' Set coefficient of a variable in a function
    Private Sub SetCoef(funstr As String, varstr As String, coef As Decimal)
        myModel.SetCoefficient(FunSList(funstr), VarSList(varstr), coef)
    End Sub

    ' Solve optimization model
    Private Sub SolveModel(funstr As String, isMin As Boolean)
        myModel.AddGoal(FunSList(funstr), 0, isMin)
        myModel.Solve(New SimplexSolverParams())
    End Sub

    'Get value of variable
    Private Function GetVarValue(varstr As String) As Decimal
        Return myModel.GetValue(VarSList(varstr)).ToDouble
    End Function

    ' Get value of function
    Private Function GetFunValue(funstr As String) As Decimal
        Return myModel.GetValue(FunSList(funstr)).ToDouble
    End Function

    ' Check optimality
    Private Function IsOptimal() As Boolean
        Return myModel.LpResult = 2
    End Function

    ' Find shortest path using linear programming
    Public Function ShortestPath(net As Network, orig As String, dest As String,
                                        ByRef length As Decimal) As List(Of Arc)

        Dim inf As Decimal = 1000000000

        If orig = dest Then
            length = inf
            Return Nothing
        End If

        ' initialize network
        For Each a In net.ArcSList.Values
            a.Flow = 0
        Next

        ' Initialize Solver
        InitSolver()

        ' Create variables
        For Each a In net.ArcSList.Values
            AddVar(a.ID, 0, 1)
        Next

        ' Create Constraints
        For Each n In net.NodeSList.Values
            Dim rhs As Integer
            Select Case n.ID
                Case orig
                    rhs = -1
                Case dest
                    rhs = 1
                Case Else
                    rhs = 0
            End Select
            AddFun(n.ID, rhs, rhs)
            For Each a In n.ArcsIn
                SetCoef(n.ID, a.ID, 1)
            Next
            For Each a In n.ArcsOut
                SetCoef(n.ID, a.ID, -1)
            Next
        Next

        ' Create objective and solve model
        AddObj("obj")
        For Each a In net.ArcSList.Values
            SetCoef("obj", a.ID, a.Cost)
        Next
        SolveModel("obj", True)

        ' Get results
        If IsOptimal() Then
            Dim list As New List(Of Arc)
            Dim n As Node = net.NodeSList(dest)
            length = 0
            Do While n.ID <> orig
                For Each a In n.ArcsIn
                    If GetVarValue(a.ID) > 0.01 Then
                        list.Insert(0, a)
                        length += a.Cost
                        n = a.Tail
                        Exit For
                    End If
                Next
            Loop
            Return list
        Else
            length = -1
            Return Nothing
        End If

    End Function

    Public Sub AssignDeliveryLocations(Net As Network)
        ' section 2.1
        InitSolver()
        For Each a In Net.DriverSList.Values
            For Each i In a.LocationSList.Keys
                Dim str As String = a.ID & "-" & i
                AddVar(str, 0, 1)
            Next
        Next
        ' section 2.2
        Dim locCount As Integer = Net.LocationDriverSList.Count
        Dim drvCount As Integer = Net.DriverSList.Count
        Dim maxLoc As Integer = Math.Ceiling(locCount / drvCount)
        Dim destList = Net.LocationDriverSList.Keys
        Dim drvList = Net.DriverSList.Values
        ' section 2.3
        For Each x In destList
            Dim sup As String = x & "_supply"
            AddFun(sup, 1, 1)
            For Each y In drvList
                Dim dv As String = y.ID & "-" & x
                SetCoef(sup, dv, 1)
            Next
        Next
        ' section 2.4
        For Each p In drvList
            Dim con As String = p.ID & "_demand"
            AddFun(con, maxLoc - 1, maxLoc)
            For Each k In destList
                Dim dec As String = p.ID & "-" & k
                SetCoef(con, dec, 1)
            Next
        Next
        ' section 2.5 
        Dim obj As String = "obj"
        AddObj(obj)
        For Each g In destList
            For Each h In drvList
                Dim stg = h.ID & "-" & g
                Dim objCoeff As Decimal = h.LocationSList(g)
                SetCoef(obj, stg, objCoeff)
            Next
        Next
        ' section 2.6
        SolveModel(obj, True)
        If IsOptimal() Then
            For Each w In drvList
                w.DeliveryList.Clear()
                For Each u In destList
                    Dim vb = w.ID & "-" & u
                    If GetVarValue(vb) > 0.1 Then
                        w.DeliveryList.Add(u)
                    End If
                Next
                With w
                    .DeliveryList.Sort()
                    .RouteList.Clear()
                    .DriverRoute = Nothing
                End With
            Next
        End If

    End Sub
End Class

